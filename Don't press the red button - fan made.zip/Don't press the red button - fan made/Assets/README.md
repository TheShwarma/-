# EGGA

Electro Gryphon Game Assets

[UPersian](https://github.com/ElectroGryphon/EGGA/tree/master/UPersian): Unity Game Engine RTL Support
