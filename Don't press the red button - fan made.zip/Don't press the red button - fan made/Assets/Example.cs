﻿using UnityEngine;
using UnityEngine.UI;

public class Example : MonoBehaviour
{
    public Text Text;
    int i = 1;

    void Start()
    {
        Text.text = "כמו שאמרתי, אל תלחץ עלי!";
    }

    void OnMouseDown()
    {
        i++;
    }

    void Update()
    {
        if (i == 2)
        {
            Text.text = "אמרתי שתפסיק ללחוץ עלי!";
        }
        if (i == 3)
        {
            Text.text = "טיפש שכמותך!";
        }
        if (i == 4)
        {
            Text.text = "אני חושב שהבנתי מה הבעיה";
        }
        if (i == 5)
        {
            Text.text = "אתה פשוט לא מבין עברית!";
        }
        if (i == 6)
        {
            Text.text = "You just don't know hebrew!";
        }
        if (i == 7)
        {
            Text.text = "ربما تفضل اللغة العربية؟";
            // אין לי מושג בדיוק מה כתבתי.
            // עשיתי גוגל טרנסלייט לאולי אתה מעדיף ערבית
        }
    }

    
}