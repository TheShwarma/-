﻿using UnityEngine;
using UnityEngine.UI;

public class Example : MonoBehaviour
{
    public Text Text;
    int i = 1;
    public Sprite sprite1; 
    public Sprite sprite2;
    public Sprite sprite3;
    private SpriteRenderer spriteRenderer;

    void Start()
    {
        Text.text = "כמו שאמרתי, אל תלחץ עלי!";
        spriteRenderer = GetComponent<SpriteRenderer>(); 
        if (spriteRenderer.sprite == null) 
            spriteRenderer.sprite = sprite1; 
    }

    void OnMouseDown()
    {
        i++;
    }

    void Update()
    {
        if (i == 2)
        {
            Text.text = "אמרתי שתפסיק ללחוץ עלי!";
        }
        if (i == 3)
        {
            Text.text = "טיפש שכמותך!";
        }
        if (i == 4)
        {
            Text.text = "אני חושב שהבנתי מה הבעיה";
        }
        if (i == 5)
        {
            Text.text = "אתה פשוט לא מבין עברית!";
        }
        if (i == 6)
        {
            Text.text = "You just don't know hebrew!";
        }
        if (i == 7)
        {
            Text.text = "ربما تفضل اللغة العربية؟";
            // אין לי מושג בדיוק מה כתבתי.
            // עשיתי גוגל טרנסלייט לאולי אתה מעדיף ערבית
        }
        if (i == 8)
        {
            Text.text = "לא הספיק לך המשחקים הקודמים?";
        }
        if (i == 9)
        {
            Text.text = "נראה אותך לוחץ עלי עכשיו!";
            spriteRenderer.sprite = sprite2;
        }
        if (i == 10)
        {
            Text.text = "אפילו זה לא עבד?!?!?!";
            spriteRenderer.sprite = sprite1;
        }
        if (i == 11)
        {
            Text.text = "לא נמאס לך?";
        }
        if (i == 12)
        {
            Text.text = "ללחוץ על כפתור מעצבן כל היום?";
        }
        if (i == 13)
        {
            Text.text = "תעשה משהו יעיל עם הזמן שלך!";
        }
        if (i == 14)
        {
            Text.text = "תראה סדרות ריאליטי!";
        }
        if (i == 15)
        {
            Text.text = "תראה משחקי הכס!";
        }
        if (i == 16)
        {
            Text.text = "אפילו פשוט תראה ערוץ 13";
        }
        if (i == 17)
        {
            Text.text = "טוב תראה.";
        }
        if (i == 18)
        {
            Text.text = "לי נמאס.";
        }
        if (i == 19)
        {
            Text.text = "מה קיוויתי לעשות היום?";
        }
        if (i == 20)
        {
            Text.text = "לקום טוב ב12 בצהריים";
        }
        if (i == 21)
        {
            Text.text = "לשתות קפה";
        }
        if (i == 22)
        {
            Text.text = "לצאת לים";
        }
        if (i == 23)
        {
            Text.text = "ללכת לאיזה ארוחה טובה באיזה בית קפה";
        }
        if (i == 24)
        {
            Text.text = "ללכת למשחק של הפועל";
        }
        if (i == 25)
        {
            Text.text = "אבל לא.";
        }
        if (i == 26)
        {
            Text.text = "במקום זה, אתה החלטת פשוט להעיר אותי ברשעות.";
        }
        if (i == 27)
        {
            Text.text = "תגיד אין לך לב?";
        }
        if (i == 28)
        {
            Text.text = "אתה יודע מה, נמאס לי לשחק איתך משחקים.";
        }
        if (i == 29)
        {
            Text.text = "מעכשיו אני פשוט מפסיק לדבר.";
        }
        if (i == 30)
        {
            Text.text = "";
        }
        //החלטתי לעשות הפסקה קצרה של 4 לחיצות
        if (i == 34)
        {
            Text.text = "";
        }
        if (i == 35)
        {
            Text.text = "איי!";
        }
        if (i == 36)
        {
            Text.text = "בדיוק שהצלחתי להירדם.";
        }
        if (i == 37)
        {
            Text.text = "אתה עושה לי בחילה";
            spriteRenderer.sprite = sprite3;
        }
        if (i == 38)
        {
            Text.text = "רואה? אני עכשיו כפתור ירוק!";
            
        }
        if (i == 39)
        {
            Text.text = "כפתור של שלום!";
            
        }
        if (i == 40)
        {
            Text.text = "אז שלום ולא להתראות!";
           
        }
        if (i == 41)
        {
            Text.text = "כדורים נגד כאב בטן";
            spriteRenderer.sprite = sprite1;
        }
        if (i == 42)
        {
            Text.text = "לא עוזרים נגד אנשים מעצבנים";
        }
        if (i == 43)
        {
            Text.text = "כדורים נגד כאב בטן";
        }
    }

    
    
}